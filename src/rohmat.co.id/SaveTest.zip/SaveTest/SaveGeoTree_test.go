package SaveTest

import (
	"database/sql"
	"fmt"
	_ "github.com/lib/pq"
	"github.com/stretchr/testify/assert"
	"github.com/tkanos/gonfig"
	"testing"
)

type inputStruct struct {
	Table string          `json:"table"`
	Rows  []dataUserLevel `json:"rows"`
}
type dataUserLevel struct {
	ID       int64
	ParentID int64
	Level    int
	Code     string
	Code1    string `json:"userLevel1ID"`
	Code2    string `json:"userLevel2ID"`
	Code3    string `json:"userLevel3ID"`
	Code4    string `json:"userLevel4ID"`
	Code5    string `json:"userLevel5ID"`
	NcCode   string `json:"principalID"`
	Name     string `json:"userLevelName"`
}

func insertGeoTree(db *sql.DB, ncID int64, userParam *dataUserLevel) (err error) {
	//funcName := "InsertDataGroup"
	query :=
		" INSERT INTO  geo_tree " +
			"  (nexchief_account_id, code, name," +
			"  level, parent_id ) " +
			" VALUES " +
			"($1, $2, $3, " +
			" $4, $5) "
	param := []interface{}{
		ncID, userParam.Code, userParam.Name,
		userParam.Level, userParam.ParentID}

	_, err = db.Exec(query, param...)

	return
}

func updateGeoTree(db *sql.DB, ncID int64, userParam *dataUserLevel) (err error) {
	//funcName := "InsertDataGroup"
	query :=
		" UPDATE  geo_tree SET " +
			"nexchief_account_id = $1, code = $2, name = $3," +
			"level = $4, parent_id = $5 " +
			"WHERE id = $6 "
	param := []interface{}{
		ncID, userParam.Code, userParam.Name,
		userParam.Level, userParam.ParentID, userParam.ID}

	_, err = db.Exec(query, param...)

	return
}

func getID(db *sql.DB, ncID int64, data *dataUserLevel) (err error) {
	query := "SELECT id FROM geo_tree WHERE nexchief_account_id = $1 AND code = $2 " +
		"AND level = $3 AND parent_id = $4 "
	param := []interface{}{ncID, data.Code, data.Level, data.ParentID}
	errs := db.QueryRow(query, param...).Scan(data.ID)
	if errs != nil && errs != sql.ErrNoRows {
		err = errs
	}
	return
}
func getParent(db *sql.DB, ncID int64, data *dataUserLevel, listData []interface{}) (err error) {

	query, param := GetQueryParent("geo_tree", "parent", "code", "", listData, 0)

	rows, err := db.Query(query, param...)
	if err != nil {
		return
	}
	if rows != nil {
		defer func() {
			err = rows.Close()
			if err != nil {
				return
			}
		}()

		for rows.Next() {
			var key string
			var id sql.NullInt64

			err = rows.Scan(&key, &id)
			if err != nil {
				return
			}
			switch key {
			case "parent":
				data.ParentID = id.Int64
			}
		}
	}
	return err
}

func TestInsertUserLevel1(t *testing.T) {
	var (
		temp            inputStruct
		nexchiefAccount NexchiefAccount
	)
	err := gonfig.GetConf("C:\\cdc-tools\\data sql\\user-level-1.json", &temp)
	if err != nil {
		assert.FailNow(t, err.Error())
	}

	db := connectDB()
	for i := 0; i < len(temp.Rows); i++ {
		data := temp.Rows[i]
		nexchiefAccount, err = getNexchiefAccountID(db, data.NcCode)
		if err != nil {
			continue
		}
		data.Level = 1
		data.Code = data.Code1
		//err = getParent(db, nexchiefAccount.ID.Int64, &data, nil)
		//if err != nil {
		//	continue
		//}
		err = getID(db, nexchiefAccount.ID.Int64, &data)
		if err != nil {
			continue
		} else if data.ID > 0 {
			// update
			err = updateGeoTree(db, nexchiefAccount.ID.Int64, &data)
		} else {
			err = insertGeoTree(db, nexchiefAccount.ID.Int64, &data)
		}
		if err != nil {
			fmt.Println(err.Error())
		}
	}
}


func TestInsertUserLeve2(t *testing.T) {
	var (
		temp            inputStruct
		nexchiefAccount NexchiefAccount
	)
	err := gonfig.GetConf("C:\\cdc-tools\\data sql\\user-level-2.json", &temp)
	if err != nil {
		assert.FailNow(t, err.Error())
	}

	db := connectDB()
	for i := 0; i < len(temp.Rows); i++ {
		data := temp.Rows[i]
		nexchiefAccount, err = getNexchiefAccountID(db, data.NcCode)
		if err != nil {
			continue
		}
		data.Level = 2
		data.Code = data.Code2
		err = getParent(db, nexchiefAccount.ID.Int64, &data, []interface{}{data.Code1})
		if err != nil {
			continue
		}
		err = getID(db, nexchiefAccount.ID.Int64, &data)
		if err != nil {
			continue
		} else if data.ID > 0 {
			// update
			err = updateGeoTree(db, nexchiefAccount.ID.Int64, &data)
		} else {
			err = insertGeoTree(db, nexchiefAccount.ID.Int64, &data)
		}
		if err != nil {
			fmt.Println(err.Error())
		}
	}
}

func TestInsertUserLeve3(t *testing.T) {
	var (
		temp            inputStruct
		nexchiefAccount NexchiefAccount
	)
	err := gonfig.GetConf("C:\\cdc-tools\\data sql\\user-level-3.json", &temp)
	if err != nil {
		assert.FailNow(t, err.Error())
	}

	db := connectDB()
	for i := 0; i < len(temp.Rows); i++ {
		data := temp.Rows[i]
		nexchiefAccount, err = getNexchiefAccountID(db, data.NcCode)
		if err != nil {
			continue
		}
		data.Level = 3
		data.Code = data.Code3
		err = getParent(db, nexchiefAccount.ID.Int64, &data, []interface{}{data.Code1, data.Code2})
		if err != nil {
			continue
		}
		err = getID(db, nexchiefAccount.ID.Int64, &data)
		if err != nil {
			continue
		} else if data.ID > 0 {
			// update
			err = updateGeoTree(db, nexchiefAccount.ID.Int64, &data)
		} else {
			err = insertGeoTree(db, nexchiefAccount.ID.Int64, &data)
		}
		if err != nil {
			fmt.Println(err.Error())
		}

	}

}

func TestInsertUserLeve4(t *testing.T) {
	var (
		temp            inputStruct
		nexchiefAccount NexchiefAccount
	)
	err := gonfig.GetConf("C:\\cdc-tools\\data sql\\user-level-4.json", &temp)
	if err != nil {
		assert.FailNow(t, err.Error())
	}

	db := connectDB()
	for i := 0; i < len(temp.Rows); i++ {
		data := temp.Rows[i]
		nexchiefAccount, err = getNexchiefAccountID(db, data.NcCode)
		if err != nil {
			continue
		}
		data.Level = 4
		data.Code = data.Code4
		err = getParent(db, nexchiefAccount.ID.Int64, &data, []interface{}{data.Code1, data.Code2, data.Code3})
		if err != nil {
			continue
		}
		err = getID(db, nexchiefAccount.ID.Int64, &data)
		if err != nil {
			continue
		} else if data.ID > 0 {
			// update
			err = updateGeoTree(db, nexchiefAccount.ID.Int64, &data)
		} else {
			err = insertGeoTree(db, nexchiefAccount.ID.Int64, &data)
		}
		if err != nil {
			fmt.Println(err.Error())
		}

	}

}

func TestInsertUserLeve5(t *testing.T) {
	var (
		temp            inputStruct
		nexchiefAccount NexchiefAccount
	)
	err := gonfig.GetConf("C:\\cdc-tools\\data sql\\user-level-5.json", &temp)
	if err != nil {
		assert.FailNow(t, err.Error())
	}

	db := connectDB()
	for i := 0; i < len(temp.Rows); i++ {
		data := temp.Rows[i]
		nexchiefAccount, err = getNexchiefAccountID(db, data.NcCode)
		if err != nil {
			continue
		}
		data.Level = 5
		data.Code = data.Code5
		err = getParent(db, nexchiefAccount.ID.Int64, &data, []interface{}{data.Code1, data.Code2, data.Code3, data.Code4})
		if err != nil {
			continue
		}
		err = getID(db, nexchiefAccount.ID.Int64, &data)
		if err != nil {
			continue
		} else if data.ID > 0 {
			// update
			err = updateGeoTree(db, nexchiefAccount.ID.Int64, &data)
		} else {
			err = insertGeoTree(db, nexchiefAccount.ID.Int64, &data)
		}
		if err != nil {
			fmt.Println(err.Error())
		}

	}

}
func TestQueryParent(t *testing.T) {
	query, param := GetQueryParent("geo_tree", "geo_tree", "code", "", []interface{}{"GEO1", "GEO2", "d","f","s"}, 0)
	fmt.Println(query)
	fmt.Println(param)
}

func TestPointer(t *testing.T) {
	arr := []string{
		"satu", "dua", "tiga", "empat",
	}
	funcTest(&arr)
	for i := 0; i < len(arr); i++ {
		fmt.Println(arr[i])
	}
}

func funcTest(arr *[]string) {
	temp := *arr
	for i := 0; i < len(temp); i++ {
		temp[i] = temp[i] + "--"
	}
}