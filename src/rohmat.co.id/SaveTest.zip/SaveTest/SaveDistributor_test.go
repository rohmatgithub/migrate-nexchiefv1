package SaveTest

import (
	"database/sql"
	"fmt"
	"github.com/stretchr/testify/assert"
	"github.com/tkanos/gonfig"
	"testing"
)

type structDistributor struct {
	Table string        `json:"table"`
	Rows  []distributor `json:"rows"`
}

type distributor struct {
	ID         int64
	Code       string `json:"distributorID"`
	Name       string `json:"distributorName"`
	Address1   string `json:"address1"`
	Address2   string `json:"address2"`
	City       string `json:"city"`
	Email      string `json:"email"`
	Phone      string `json:"phone"`
	Fax        string `json:"fax"`
	ParentCode string `json:"parentID"`
	Npwp       string `json:"distributorNPWP"`
}

type mappingDistributor struct {
	NcID int64
	ID   int64
}

func getDistributor(db *sql.DB, data *distributor) (result []mappingDistributor, err error) {
	query :=
		"SELECT id, nexchief_account_id " +
			"FROM mapping_nexseller WHERE code = $1 "
	param := []interface{}{data.Code}
	rows, err := db.Query(query, param...)
	if err != nil {
		return
	}
	if rows != nil {
		defer func() {
			err = rows.Close()
			if err != nil {
				return
			}
		}()

		for rows.Next() {
			var temp mappingDistributor

			err = rows.Scan(&temp.ID, &temp.NcID)
			if err != nil {
				return
			}
			result = append(result, temp)
		}
	}
	return
}

func getParentID(db *sql.DB, model *mappingDistributor) (id int64, err error) {
	query :=
		"SELECT id FROM mapping_nexseller WHERE id = $1 AND nexchief_account_id = $2"
	param := []interface{}{model.ID, model.NcID}
	errS := db.QueryRow(query, param...).Scan(&id)
	if errS != nil && errS != sql.ErrNoRows {
		err = errS
	}
	return
}

func getIDCompanyProfile(db *sql.DB, model *distributor) (id int64, err error) {
	query :=
		"SELECT id FROM company_profile WHERE name = $1 AND address_1 = $2 AND address_2 = $3 " +
			"AND npwp = $4 AND district = $5 AND phone = $6 AND email = $7 "
	param := []interface{}{model.Name, model.Address1, model.Address2,
		model.Npwp, model.City, model.Phone, model.Email}
	errS := db.QueryRow(query, param...).Scan(&id)
	if errS != nil && errS != sql.ErrNoRows {
		err = errS
	}
	return
}

func insertCompanyProfile(db *sql.DB, userParam *distributor) (id int64, err error) {
	//funcName := "InsertDataGroup"
	query :=
		" INSERT INTO  company_profile " +
			"  (name, address_1, address_2," +
			"  district, email, phone, " +
			"  fax, npwp) " +
			" VALUES " +
			"($1, $2, $3, " +
			" $4, $5, $6, " +
			" $7, $8) " +
			"RETURNING id"
	param := []interface{}{
		userParam.Name, userParam.Address1, userParam.Address2,
		userParam.City, userParam.Email, userParam.Phone,
		userParam.Fax, userParam.Npwp}

	err = db.QueryRow(query, param...).Scan(&id)

	return
}

func updateMappingNexseller(db *sql.DB, id, cpID, parentID int64) (err error) {
	query := "UPDATE mapping_nexseller SET " +
		"company_profile_id = $1, parent_id = $2 " +
		"WHERE id = $3 "
	_, err = db.Exec(query, cpID, parentID, id)
	return err
}

func TestInsertCompanyProfile(t *testing.T) {
	var (
		temp structDistributor
	)
	err := gonfig.GetConf("C:\\cdc-tools\\data sql\\distributor.json", &temp)
	if err != nil {
		assert.FailNow(t, err.Error())
	}

	db := connectDB()
	for i := 0; i < len(temp.Rows); i++ {
		data := temp.Rows[i]
		// get company profile
		var (
			cpID, parentID int64
			resultDB       []mappingDistributor
		)
		cpID, err = getIDCompanyProfile(db, &data)
		if err != nil {
			fmt.Println("err company profile : ", err.Error())
			continue
		} else if cpID == 0 {
			// insert
			cpID, err = insertCompanyProfile(db, &data)
			if err != nil {
				fmt.Println("insert company profile : ", err.Error())
				continue
			}
		}
		resultDB, err = getDistributor(db, &data)
		if err != nil {
			fmt.Println("get distributor : ", err.Error())
			continue
		}

		for _, m := range resultDB {
			parentID, err = getParentID(db, &m)
			if err != nil {
				fmt.Println("get parent id : ", err.Error())
				continue
			}
			err = updateMappingNexseller(db, m.ID, cpID, parentID)
			if err != nil {
				fmt.Println("update mapping nexseller : ", err.Error())
				continue
			}
		}
	}
}
