package SaveTest

import (
	"database/sql"
	"encoding/json"
	"fmt"
	"github.com/stretchr/testify/assert"
	"github.com/tkanos/gonfig"
	"testing"
)

type structMappingDistributor struct {
	Table string             `json:"table"`
	Rows  []mappingNexseller `json:"rows"`
}

type addInfo struct {
	MappingField1  string `json:"mapping_field_1"`
	MappingField2  string `json:"mapping_field_2"`
	MappingField3  string `json:"mapping_field_3"`
	MappingField4  string `json:"mapping_field_4"`
	MappingField5  string `json:"mapping_field_5"`
	MappingField6  string `json:"mapping_field_6"`
	MappingField7  string `json:"mapping_field_7"`
	MappingField8  string `json:"mapping_field_8"`
	MappingField9  string `json:"mapping_field_9"`
	MappingField10 string `json:"mapping_field_10"`
}
type mappingNexseller struct {
	ID                      int64
	GeoTreeID               int64
	PriceGroupID            int64
	ProductCategoryID       int64
	NcCode                  string `json:"principalID"`
	Code                    string `json:"distributorID"`
	IsProductMapping        string `json:"isProductMapping"`
	IsSalesmanMapping       string `json:"isSalesmanMapping"`
	IsCustomerMapping       string `json:"isCustomerMapping"`
	UserLevel1              string `json:"userLevel1ID"`
	UserLevel2              string `json:"userLevel2ID"`
	UserLevel3              string `json:"userLevel3ID"`
	UserLevel4              string `json:"userLevel4ID"`
	UserLevel5              string `json:"userLevel5ID"`
	MappingField1           string `json:"mappingField1"`
	MappingField2           string `json:"mappingField2"`
	MappingField3           string `json:"mappingField3"`
	MappingField4           string `json:"mappingField4"`
	MappingField5           string `json:"mappingField5"`
	MappingField6           string `json:"mappingField6"`
	MappingField7           string `json:"mappingField7"`
	MappingField8           string `json:"mappingField8"`
	MappingField9           string `json:"mappingField9"`
	MappingField10          string `json:"mappingField10"`
	ResignDate              string `json:"resignDate"`
	ActiveDate              string `json:"activeDate"`
	PriceGroupCode          string `json:"priceGroupID"`
	ProductClassFrom        int    `json:"productClassFrom"`
	ProductClassThru        int    `json:"productClassThru"`
	ProductCategoryCode     string `json:"productCategoryID"`
	EmailData               string `json:"emailData"`
	SyncMethod              string `json:"syncMethod"`
	LastDMSSyncStr          string `json:"lastDMSSync"`
	LastSFASyncStr          string `json:"lastSFASync"`
	//LastDMSSync             time.Time
	//LastSFASync             time.Time
	HostingOnly             string `json:"hostingOnly"`
	GromartMerchantID       string `json:"gromartMerchantID"`
	IsGenerateDelivery      string `json:"isGenerateDelivery"`
	EmailTo                 string `json:"emailTo"`
	EmailToCC               string `json:"emailToCC"`
	PrefixDeleted           string `json:"prefixDeleted"`
	Nd6ClosedDate           string `json:"nd6ClosedDate"`
	SocketUserID            string `json:"socketUserID"`
	SocketPassword          string `json:"socketPassword"`
	SocketStatus            string `json:"socketStatus"`
	ProductRegistrationDate string `json:"productRegistrationDate"`
	ProductValidThru        string `json:"productValidThru"`
}

func getMappingNexseller(db *sql.DB, ncId int64, data *mappingNexseller) (err error) {
	query :=
		"SELECT 'mn', id FROM mapping_nexseller where nexchief_account_id = $1 AND code = $2 " +
			"UNION ALL " +
			"SELECT 'pg', id FROM price_group where nexchief_account_id = $1 AND code = $3 " +
			"UNION ALL " +
			"SELECT 'pc', id FROM product_category where nexchief_account_id = $1 AND code = $4 " +
			"UNION ALL "
	tempQuery, tempParam := GetQueryParent("geo_tree", "gt", "code", "", []interface{}{
		data.UserLevel1, data.UserLevel2, data.UserLevel3, data.UserLevel4, data.UserLevel5,
	}, 4)

	query += tempQuery
	param := []interface{}{ncId, data.Code, data.PriceGroupCode, data.ProductCategoryCode}
	param = append(param, tempParam...)

	rows, err := db.Query(query, param...)
	if err != nil {
		return
	}
	if rows != nil {
		defer func() {
			err = rows.Close()
			if err != nil {
				return
			}
		}()

		for rows.Next() {
			var key string
			var id sql.NullInt64

			err = rows.Scan(&key, &id)
			if err != nil {
				return
			}
			switch key {
			case "mn":
				data.ID = id.Int64
			case "pg":
				data.PriceGroupID = id.Int64
			case "pc":
				data.ProductCategoryID = id.Int64
			case "gt":
				data.GeoTreeID = id.Int64
			}
		}
	}
	return
}

func insertMappingNexseller(db *sql.DB, ncID int64, data *mappingNexseller) (err error) {
	query :=
		"INSERT INTO mapping_nexseller " +
			"(nexchief_account_id, code, geo_tree_id, " +
			"is_product_mapping, is_salesman_mapping, is_customer_mapping," +
			"hosting_only, is_generate_delivery, email_data, sync_method, " +
			"additional_info, active_date, resign_date, " +
			"price_group_id, product_category_id, nexseller_product_class_from," +
			"nexseller_product_class_thru, last_dms_sync, last_sfa_sync, " +
			"gromart_merchant_id, prefix_deleted, nd6_closed_date, " +
			"socket_user_id, socket_password, socket_status, " +
			"email_to, email_to_cc, product_registration_date, product_valid_thru )" +
			"VALUES " +
			"($1, $2, $3, " +
			"$4, $5, $6, " +
			"$7, $8, $9, $10, " +
			"$11, $12, $13, " +
			"$14, $15, $16, " +
			"$17, $18, $19, " +
			"$20, $21, $22, " +
			"$23, $24, $25, " +
			"$26, $27, $28, $29)"
	param := []interface{}{
		ncID, data.Code, data.GeoTreeID,
		getBool(data.IsProductMapping), getBool(data.IsSalesmanMapping), getBool(data.IsCustomerMapping),
		data.HostingOnly, getBool(data.IsGenerateDelivery), data.EmailData, data.SyncMethod,
		StructToJSON(addInfo{
			MappingField1:  data.MappingField1,
			MappingField2:  data.MappingField2,
			MappingField3:  data.MappingField3,
			MappingField4:  data.MappingField4,
			MappingField5:  data.MappingField5,
			MappingField6:  data.MappingField6,
			MappingField7:  data.MappingField7,
			MappingField8:  data.MappingField8,
			MappingField9:  data.MappingField9,
			MappingField10: data.MappingField10,
		}), getNull(data.ActiveDate), getNull(data.ResignDate),
		data.PriceGroupID, data.ProductCategoryID, data.ProductClassFrom,
		data.ProductClassThru, getNull(data.LastDMSSyncStr), getNull(data.LastSFASyncStr),
		data.GromartMerchantID, data.PrefixDeleted, getNull(data.Nd6ClosedDate),
		data.SocketUserID, data.SocketPassword, getNull(data.SocketStatus),
		data.EmailTo, data.EmailToCC, getNull(data.ProductRegistrationDate), getNull(data.ProductValidThru),
	}
	_, err = db.Exec(query, param...)
	return err
}

func getNull(str string)interface{}{
	if str == "" {
		return nil
	}
	return str
}
func getBool(str string) bool {
	if str == "Y" {
		return true
	}
	return false
}

func StructToJSON(input interface{}) (output string) {
	b, err := json.Marshal(input)
	if err != nil {
		fmt.Println(err)
		output = ""
		return
	}
	output = string(b)
	return
}

func TestInsertMappingNexseller(t *testing.T) {
	var (
		temp            structMappingDistributor
		nexchiefAccount NexchiefAccount
	)
	err := gonfig.GetConf("C:\\cdc-tools\\data sql\\mapping-distributor.json", &temp)
	if err != nil {
		assert.FailNow(t, err.Error())
	}

	db := connectDB()

	for i := 0; i < len(temp.Rows); i++ {
		data := temp.Rows[i]
		nexchiefAccount, err = getNexchiefAccountID(db, data.NcCode)
		if err != nil {
			continue
		}
		//err = getParent(db, nexchiefAccount.ID.Int64, &data, nil)
		//if err != nil {
		//	continue
		//}
		err = getMappingNexseller(db, nexchiefAccount.ID.Int64, &data)
		if err != nil {
			fmt.Println(err)
			continue
		} else if data.ID == 0 {
			// insert
			err = insertMappingNexseller(db, nexchiefAccount.ID.Int64, &data)
		}
		if err != nil {
			fmt.Println(err.Error())
		}
	}
}
