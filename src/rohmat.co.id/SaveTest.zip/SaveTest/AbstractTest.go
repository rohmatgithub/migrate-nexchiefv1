package SaveTest

import (
	"database/sql"
	"errors"
	"fmt"
	"strconv"
)

var MapNexchiefAccount = make(map[string]NexchiefAccount)

type NexchiefAccount struct {
	ID     sql.NullInt64
	Schema sql.NullString
}

func connectDB() (db *sql.DB) {
	const (
		host     = "localhost"
		port     = 5432
		user     = "nexchief"
		password = "nexChief"
		dbname   = "nexSOFT"
		schema   = "nexchief"
	)
	psqlInfo := fmt.Sprintf("host=%s port=%d user=%s "+
		"password=%s dbname=%s sslmode=disable search_path=%s",
		host, port, user, password, dbname, schema)

	db, err := sql.Open("postgres", psqlInfo)
	if err != nil {
		panic(err)
	}
	if err = db.Ping(); err != nil {
		panic(err)
	}
	return
}


func GetQueryParent(tableName, key, fieldClause, schema string, listData []interface{}, lengthParam int) (query string, queryParam []interface{}) {
	//level -> level parent
	query += fmt.Sprintf("SELECT '%s', ", key)
	//"SELECT pg2.id FROM product_group_hierarchy pg2 " +
	//"LEFT JOIN product_group_hierarchy pg1 ON pg2.parent_id = pg1.id " +
	//"WHERE pg2.code = $1 AND pg1.code = $2 AND nexchief_account_id = $3 AND mapping_principal_id = $4 "
	clause := " "
	for i := len(listData); i > 0; i-- {
		if i == len(listData) {
			query += fmt.Sprintf(" lv%d.id FROM %s lv%d", i, tableName, i)
		} else {
			query += fmt.Sprintf(" LEFT JOIN %s lv%d ON lv%d.id = lv%d.parent_id ", tableName, i, i, i+1)
		}
		clause += fmt.Sprintf(" lv%d.%s = $%d ", i, fieldClause, lengthParam+1)
		if i > 1 {
			clause += "AND"
		}
		lengthParam++
		queryParam = append(queryParam, listData[i-1])
	}
	query += " WHERE " + clause + " AND lv" + strconv.Itoa(len(listData)) + ".level = $" + strconv.Itoa(lengthParam+1)
	queryParam = append(queryParam, len(listData))
	return
}


func getNexchiefAccountID(db *sql.DB, code string) (result NexchiefAccount, err error) {
	result = MapNexchiefAccount[code]

	// get to db if null in map
	if result.ID.Int64 == 0 {
		fmt.Println("get nexchief account from db :", code)
		query :=
			" SELECT id, schema from nexchief_account WHERE code = $1 "
		param := []interface{}{code}

		err = db.QueryRow(query, param...).Scan(&result.ID, &result.Schema)
		if err != nil && err != sql.ErrNoRows {
			return
		}
		if result.ID.Int64 > 0 && result.Schema.String != "" {
			MapNexchiefAccount[code] = result
		} else {
			err = errors.New("nexchief account not found")
		}
	}
	return
}
